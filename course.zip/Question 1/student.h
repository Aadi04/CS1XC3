/**
 * @file student.h
 */

/**
 *@brief The student struct consists of the first and last name, their ID, and their grades. 
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; // **< Student's First Name */
  char last_name[50];//**<Student's Last Name */
  char id[11];//**<Student's Id*/
  double *grades; //**<Student's Grades */
  int num_grades; //*< Student's Number Grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
