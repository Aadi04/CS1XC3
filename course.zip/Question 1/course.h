/**
 * @file course.h
 */

#include "student.h"
#include <stdbool.h>

/**
 *@brief The course consists of name of the course, code, students enrolled in the course, and the total students
 * 
 */
typedef struct _course 
{
  char name[100]; // **< The Course name */
  char code[10];//**< The Course Code */
  Student *students; //**< The students enrolled */
  int total_students; //**< Total Students in the Course */7
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


